/**
 */
package org.gemoc.models17.fsm.xfsm.model.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import org.gemoc.models17.fsm.xfsm.model.Buffer;
import org.gemoc.models17.fsm.xfsm.model.ModelFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Buffer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link org.gemoc.models17.fsm.xfsm.model.Buffer#initialize() <em>Initialize</em>}</li>
 *   <li>{@link org.gemoc.models17.fsm.xfsm.model.Buffer#isEmpty() <em>Is Empty</em>}</li>
 *   <li>{@link org.gemoc.models17.fsm.xfsm.model.Buffer#enqueue(java.lang.String) <em>Enqueue</em>}</li>
 *   <li>{@link org.gemoc.models17.fsm.xfsm.model.Buffer#dequeue() <em>Dequeue</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class BufferTest extends TestCase {

	/**
	 * The fixture for this Buffer test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Buffer fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(BufferTest.class);
	}

	/**
	 * Constructs a new Buffer test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BufferTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Buffer test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Buffer fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Buffer test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Buffer getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ModelFactory.eINSTANCE.createBuffer());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link org.gemoc.models17.fsm.xfsm.model.Buffer#initialize() <em>Initialize</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.gemoc.models17.fsm.xfsm.model.Buffer#initialize()
	 * @generated
	 */
	public void testInitialize() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link org.gemoc.models17.fsm.xfsm.model.Buffer#isEmpty() <em>Is Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.gemoc.models17.fsm.xfsm.model.Buffer#isEmpty()
	 * @generated
	 */
	public void testIsEmpty() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link org.gemoc.models17.fsm.xfsm.model.Buffer#enqueue(java.lang.String) <em>Enqueue</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.gemoc.models17.fsm.xfsm.model.Buffer#enqueue(java.lang.String)
	 * @generated
	 */
	public void testEnqueue__String() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link org.gemoc.models17.fsm.xfsm.model.Buffer#dequeue() <em>Dequeue</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.gemoc.models17.fsm.xfsm.model.Buffer#dequeue()
	 * @generated
	 */
	public void testDequeue() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //BufferTest
