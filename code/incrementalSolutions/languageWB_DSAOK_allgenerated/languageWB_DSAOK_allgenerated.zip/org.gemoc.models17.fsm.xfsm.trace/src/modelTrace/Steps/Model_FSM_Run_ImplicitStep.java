/**
 */
package modelTrace.Steps;

import fr.inria.diverse.trace.commons.model.trace.SmallStep;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model FSM Run Implicit Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelTrace.Steps.StepsPackage#getModel_FSM_Run_ImplicitStep()
 * @model
 * @generated
 */
public interface Model_FSM_Run_ImplicitStep extends Model_FSM_Run_AbstractSubStep, SmallStep {
} // Model_FSM_Run_ImplicitStep
