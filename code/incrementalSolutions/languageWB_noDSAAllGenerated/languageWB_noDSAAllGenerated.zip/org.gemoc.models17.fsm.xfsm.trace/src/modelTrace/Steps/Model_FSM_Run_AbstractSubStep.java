/**
 */
package modelTrace.Steps;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model FSM Run Abstract Sub Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelTrace.Steps.StepsPackage#getModel_FSM_Run_AbstractSubStep()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Model_FSM_Run_AbstractSubStep extends SpecificStep {
} // Model_FSM_Run_AbstractSubStep
