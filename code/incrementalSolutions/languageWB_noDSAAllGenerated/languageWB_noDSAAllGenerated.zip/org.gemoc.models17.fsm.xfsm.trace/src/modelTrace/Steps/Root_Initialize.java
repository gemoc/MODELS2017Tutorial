/**
 */
package modelTrace.Steps;

import fr.inria.diverse.trace.commons.model.trace.SmallStep;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Root Initialize</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelTrace.Steps.StepsPackage#getRoot_Initialize()
 * @model
 * @generated
 */
public interface Root_Initialize extends SpecificStep, SmallStep {
} // Root_Initialize
