package org.gemoc.models17.fsm.semantics.model.aspects;

import model.State;

@SuppressWarnings("all")
public class FSMAspectFSMAspectProperties {
  public State currentState;
  
  public String underProcessTrigger;
  
  public String consummedString;
}
