package org.gemoc.models17.fsm.xfsm.aspects;

@SuppressWarnings("all")
public class BufferAspectBufferAspectProperties {
  public String currentValues;
}
