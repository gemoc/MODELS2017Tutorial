package org.gemoc.models17.fsm.xfsm.adapters.xfsmmt.model;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.models17.fsm.xfsm.adapters.xfsmmt.XFSMMTAdaptersFactory;
import org.gemoc.models17.fsm.xfsmmt.model.Buffer;
import org.gemoc.models17.fsm.xfsmmt.model.FSM;
import org.gemoc.models17.fsm.xfsmmt.model.ModelFactory;
import org.gemoc.models17.fsm.xfsmmt.model.ModelPackage;
import org.gemoc.models17.fsm.xfsmmt.model.State;
import org.gemoc.models17.fsm.xfsmmt.model.Transition;

@SuppressWarnings("all")
public class ModelFactoryAdapter extends EFactoryImpl implements ModelFactory {
  private XFSMMTAdaptersFactory adaptersFactory = org.gemoc.models17.fsm.xfsm.adapters.xfsmmt.XFSMMTAdaptersFactory.getInstance();
  
  private org.gemoc.models17.fsm.xfsm.model.ModelFactory modelAdaptee = org.gemoc.models17.fsm.xfsm.model.ModelFactory.eINSTANCE;
  
  @Override
  public FSM createFSM() {
    return adaptersFactory.createFSMAdapter(modelAdaptee.createFSM(), null);
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(modelAdaptee.createState(), null);
  }
  
  @Override
  public Buffer createBuffer() {
    return adaptersFactory.createBufferAdapter(modelAdaptee.createBuffer(), null);
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(modelAdaptee.createTransition(), null);
  }
  
  @Override
  public org.gemoc.models17.fsm.xfsmmt.model.System createSystem() {
    return adaptersFactory.createSystemAdapter(modelAdaptee.createSystem(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getModelPackage();
  }
  
  public ModelPackage getModelPackage() {
    return org.gemoc.models17.fsm.xfsmmt.model.ModelPackage.eINSTANCE;
  }
}
