package org.gemoc.models17.fsm.semantics.model.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.ReplaceAspectMethod;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import model.FSM;
import model.State;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.gemoc.models17.fsm.semantics.model.aspects.BufferAspect;
import org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties;
import org.gemoc.models17.fsm.semantics.model.aspects.StateAspect;

@Aspect(className = FSM.class)
@SuppressWarnings("all")
public class FSMAspect {
  public static void initializeFSM(final FSM _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    _privk3_initializeFSM(_self_, _self);;
  }
  
  @Step
  @ReplaceAspectMethod
  public static void run(final FSM _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    	@Override
    	public void execute() {
    		_privk3_run(_self_, _self);
    	}
    };
    fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    if (stepManager != null) {
    	stepManager.executeStep(_self,command,"FSM","run");
    } else {
    	command.execute();
    }
    ;;
  }
  
  public static State currentState(final FSM _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_currentState(_self_, _self);;
    return (model.State)result;
  }
  
  public static void currentState(final FSM _self, final State currentState) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    _privk3_currentState(_self_, _self,currentState);;
  }
  
  public static String underProcessTrigger(final FSM _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_underProcessTrigger(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static void underProcessTrigger(final FSM _self, final String underProcessTrigger) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    _privk3_underProcessTrigger(_self_, _self,underProcessTrigger);;
  }
  
  public static String consummedString(final FSM _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_consummedString(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static void consummedString(final FSM _self, final String consummedString) {
    final org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.FSMAspectFSMAspectContext.getSelf(_self);
    _privk3_consummedString(_self_, _self,consummedString);;
  }
  
  protected static void _privk3_initializeFSM(final FSMAspectFSMAspectProperties _self_, final FSM _self) {
    InputOutput.<String>println("init FSM");
    FSMAspect.currentState(_self, _self.getInitialState());
    FSMAspect.underProcessTrigger(_self, "");
    FSMAspect.consummedString(_self, "");
  }
  
  protected static void _privk3_run(final FSMAspectFSMAspectProperties _self_, final FSM _self) {
    FSMAspect.underProcessTrigger(_self, BufferAspect.dequeue(_self.getInputBuffer()));
    String _name = _self.getName();
    String _plus = ("run SM" + _name);
    String _plus_1 = (_plus + " step on ");
    String _underProcessTrigger = FSMAspect.underProcessTrigger(_self);
    String _plus_2 = (_plus_1 + _underProcessTrigger);
    InputOutput.<String>println(_plus_2);
    StateAspect.step(FSMAspect.currentState(_self), FSMAspect.underProcessTrigger(_self));
    FSMAspect.underProcessTrigger(_self, "");
  }
  
  protected static State _privk3_currentState(final FSMAspectFSMAspectProperties _self_, final FSM _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getCurrentState") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (model.State) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.currentState;
  }
  
  protected static void _privk3_currentState(final FSMAspectFSMAspectProperties _self_, final FSM _self, final State currentState) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setCurrentState")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, currentState);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.currentState = currentState;
    }
  }
  
  protected static String _privk3_underProcessTrigger(final FSMAspectFSMAspectProperties _self_, final FSM _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getUnderProcessTrigger") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.underProcessTrigger;
  }
  
  protected static void _privk3_underProcessTrigger(final FSMAspectFSMAspectProperties _self_, final FSM _self, final String underProcessTrigger) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setUnderProcessTrigger")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, underProcessTrigger);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.underProcessTrigger = underProcessTrigger;
    }
  }
  
  protected static String _privk3_consummedString(final FSMAspectFSMAspectProperties _self_, final FSM _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getConsummedString") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.consummedString;
  }
  
  protected static void _privk3_consummedString(final FSMAspectFSMAspectProperties _self_, final FSM _self, final String consummedString) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setConsummedString")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, consummedString);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.consummedString = consummedString;
    }
  }
}
