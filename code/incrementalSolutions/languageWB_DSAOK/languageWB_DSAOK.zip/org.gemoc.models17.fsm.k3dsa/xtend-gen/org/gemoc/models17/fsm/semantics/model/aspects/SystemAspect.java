package org.gemoc.models17.fsm.semantics.model.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.InitializeModel;
import fr.inria.diverse.k3.al.annotationprocessor.Main;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import model.Buffer;
import model.FSM;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.gemoc.models17.fsm.semantics.model.aspects.BufferAspect;
import org.gemoc.models17.fsm.semantics.model.aspects.FSMAspect;
import org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties;

@Aspect(className = model.System.class)
@SuppressWarnings("all")
public class SystemAspect {
  @Step
  @InitializeModel
  public static void initialize(final model.System _self, final EList<String> p) {
    final org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectContext.getSelf(_self);
    fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    	@Override
    	public void execute() {
    		_privk3_initialize(_self_, _self,p);
    	}
    };
    fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    if (stepManager != null) {
    	stepManager.executeStep(_self,command,"System","initialize");
    } else {
    	command.execute();
    }
    ;;
  }
  
  @Main
  public static void main(final model.System _self) {
    final org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties _self_ = org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectContext.getSelf(_self);
    _privk3_main(_self_, _self);;
  }
  
  protected static void _privk3_initialize(final SystemAspectSystemAspectProperties _self_, final model.System _self, final EList<String> p) {
    InputOutput.<String>println("[INIT] Started");
    EList<FSM> _ownedFsms = _self.getOwnedFsms();
    for (final FSM sm : _ownedFsms) {
      FSMAspect.initializeFSM(sm);
    }
    EList<Buffer> _ownedBuffers = _self.getOwnedBuffers();
    for (final Buffer b : _ownedBuffers) {
      BufferAspect.initialize(b);
    }
    InputOutput.<String>println("[INIT] Completed");
  }
  
  protected static void _privk3_main(final SystemAspectSystemAspectProperties _self_, final model.System _self) {
    boolean anFSMRan = true;
    while (anFSMRan) {
      {
        anFSMRan = false;
        try {
          EList<FSM> _ownedFsms = _self.getOwnedFsms();
          for (final FSM sm : _ownedFsms) {
            boolean _isEmpty = BufferAspect.isEmpty(sm.getInputBuffer());
            boolean _not = (!_isEmpty);
            if (_not) {
              sm.run();
              anFSMRan = true;
            }
          }
        } catch (final Throwable _t) {
          if (_t instanceof Exception) {
            final Exception nt = (Exception)_t;
            String _message = nt.getMessage();
            String _plus = ("Warning due to " + _message);
            InputOutput.<String>println(_plus);
          } else {
            throw Exceptions.sneakyThrow(_t);
          }
        }
      }
    }
    InputOutput.<String>println("no more FSM to run");
  }
}
