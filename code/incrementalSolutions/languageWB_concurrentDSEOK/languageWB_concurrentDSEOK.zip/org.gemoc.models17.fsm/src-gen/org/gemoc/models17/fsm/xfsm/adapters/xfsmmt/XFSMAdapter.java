package org.gemoc.models17.fsm.xfsm.adapters.xfsmmt;

import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.gemoc.models17.fsm.XFSMMT;
import org.gemoc.models17.fsm.xfsmmt.model.ModelFactory;

@SuppressWarnings("all")
public class XFSMAdapter extends ResourceAdapter implements XFSMMT {
  public XFSMAdapter() {
    super(org.gemoc.models17.fsm.xfsm.adapters.xfsmmt.XFSMMTAdaptersFactory.getInstance());
  }
  
  @Override
  public ModelFactory getModelFactory() {
    return new org.gemoc.models17.fsm.xfsm.adapters.xfsmmt.model.ModelFactoryAdapter();
  }
  
  @Override
  public Set getFactories() {
    java.util.Set<org.eclipse.emf.ecore.EFactory> res = new java.util.HashSet<org.eclipse.emf.ecore.EFactory>();
    res.add(getModelFactory());
    return res;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
