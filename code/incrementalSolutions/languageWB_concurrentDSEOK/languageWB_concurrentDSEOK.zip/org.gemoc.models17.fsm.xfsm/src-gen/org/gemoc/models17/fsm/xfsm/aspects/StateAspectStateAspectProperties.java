package org.gemoc.models17.fsm.xfsm.aspects;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
