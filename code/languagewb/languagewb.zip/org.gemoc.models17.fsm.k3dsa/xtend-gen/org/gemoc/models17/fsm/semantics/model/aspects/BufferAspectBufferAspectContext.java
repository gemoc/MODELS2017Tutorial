package org.gemoc.models17.fsm.semantics.model.aspects;

import java.util.Map;
import model.Buffer;
import org.gemoc.models17.fsm.semantics.model.aspects.BufferAspectBufferAspectProperties;

@SuppressWarnings("all")
public class BufferAspectBufferAspectContext {
  public final static BufferAspectBufferAspectContext INSTANCE = new BufferAspectBufferAspectContext();
  
  public static BufferAspectBufferAspectProperties getSelf(final Buffer _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.gemoc.models17.fsm.semantics.model.aspects.BufferAspectBufferAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Buffer, BufferAspectBufferAspectProperties> map = new java.util.WeakHashMap<model.Buffer, org.gemoc.models17.fsm.semantics.model.aspects.BufferAspectBufferAspectProperties>();
  
  public Map<Buffer, BufferAspectBufferAspectProperties> getMap() {
    return map;
  }
}
