package org.gemoc.models17.fsm.semantics.model.aspects;

import java.util.Map;
import org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties;

@SuppressWarnings("all")
public class SystemAspectSystemAspectContext {
  public final static SystemAspectSystemAspectContext INSTANCE = new SystemAspectSystemAspectContext();
  
  public static SystemAspectSystemAspectProperties getSelf(final model.System _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<model.System, SystemAspectSystemAspectProperties> map = new java.util.WeakHashMap<model.System, org.gemoc.models17.fsm.semantics.model.aspects.SystemAspectSystemAspectProperties>();
  
  public Map<model.System, SystemAspectSystemAspectProperties> getMap() {
    return map;
  }
}
