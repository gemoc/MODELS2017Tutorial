package org.gemoc.models17.fsm.semantics.model.aspects;

@SuppressWarnings("all")
public class BufferAspectBufferAspectProperties {
  public String currentValues;
}
